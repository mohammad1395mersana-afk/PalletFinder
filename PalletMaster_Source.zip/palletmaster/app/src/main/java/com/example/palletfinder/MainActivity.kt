package com.example.palletfinder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.security.MessageDigest
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.json.JSONArray
import org.json.JSONObject

private data class Place(val code: String, val side: String, val level: String, val pallet: String)

class MainActivity : Activity() {
    private val rows = mutableListOf<Place>()
    private val index = linkedMapOf<String, MutableList<Place>>()
    private lateinit var storage: android.content.SharedPreferences
    private lateinit var query: EditText
    private lateinit var results: LinearLayout
    private lateinit var countLabel: TextView
    private var lastSearchQuery: String? = null
    private val importCode = 10
    private val exportCode = 11

    private val ink = Color.rgb(27, 43, 64)
    private val navy = Color.rgb(24, 54, 86)
    private val blue = Color.rgb(35, 112, 174)
    private val pale = Color.rgb(241, 246, 251)
    private val muted = Color.rgb(104, 120, 138)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = getSharedPreferences("pallet_data", MODE_PRIVATE)
        loadSaved()
        rebuildIndex()
        showPasswordGate()
    }

    private fun showPasswordGate() {
        val savedHash = storage.getString("master_password_hash", null)
        val firstSetup = savedHash.isNullOrBlank()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(4))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val password = EditText(this).apply {
            hint = if (firstSetup) "رمز عبور جدید" else "رمز عبور"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            textSize = 18f
        }
        box.addView(password, LinearLayout.LayoutParams(-1, dp(54)))
        var repeat: EditText? = null
        if (firstSetup) {
            repeat = EditText(this).apply {
                hint = "تکرار رمز عبور"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                textSize = 18f
            }
            box.addView(repeat, LinearLayout.LayoutParams(-1, dp(54)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (firstSetup) "ساخت رمز ورود پالت‌مستر" else "ورود به پالت‌مستر")
            .setMessage(if (firstSetup) "برای اولین ورود، یک رمز شخصی تعیین کنید." else "برای ادامه، رمز عبور خود را وارد کنید.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton(if (firstSetup) "ثبت رمز و ورود" else "ورود", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val entered = password.text.toString()
                if (entered.length < 4) {
                    password.error = "رمز باید حداقل ۴ نویسه باشد"
                    return@setOnClickListener
                }
                if (firstSetup) {
                    if (entered != repeat?.text.toString()) {
                        repeat?.error = "تکرار رمز یکسان نیست"
                        return@setOnClickListener
                    }
                    storage.edit().putString("master_password_hash", hashPassword(entered)).apply()
                    dialog.dismiss()
                    openMainScreen()
                } else if (hashPassword(entered) == savedHash) {
                    dialog.dismiss()
                    openMainScreen()
                } else {
                    password.error = "رمز عبور اشتباه است"
                    password.setText("")
                }
            }
        }
        dialog.show()
    }

    private fun hashPassword(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun openMainScreen() {
        buildUi()
        render()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(9, 28, 48), Color.rgb(27, 73, 105), Color.rgb(222, 234, 241)))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = rounded(navy, 18)
        }
        header.addView(TextView(this).apply {
            text = "PALLET MASTER"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "پالت‌مستر | جستجوی هوشمند محل کالا"
            textSize = 15f
            setTextColor(Color.rgb(220, 232, 244))
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        query = EditText(this).apply {
            hint = "کد کالا را وارد کنید"
            textSize = 20f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(ink)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, 12, Color.rgb(215, 225, 235))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val queryParams = LinearLayout.LayoutParams(-1, -2)
        queryParams.topMargin = dp(14)
        root.addView(query, queryParams)

        val search = actionButton("جستجوی کد", Color.rgb(10, 115, 170)) {
            lastSearchQuery = normalize(query.text.toString())
            render()
        }.apply { textSize = 17f; typeface = Typeface.DEFAULT_BOLD }
        val searchParams = LinearLayout.LayoutParams(-1, dp(54))
        searchParams.topMargin = dp(8)
        root.addView(search, searchParams)

        countLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(6))
        }
        root.addView(countLabel)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(results)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("ورود اکسل", blue) { chooseImport() }, weightParams())
        actions.addView(actionButton("خروجی اکسل", Color.rgb(65, 130, 105)) { chooseExport() }, weightParams())
        actions.addView(actionButton("ثبت کد", navy) { editPlace(null) }, weightParams())
        val actionParams = LinearLayout.LayoutParams(-1, -2)
        actionParams.topMargin = dp(10)
        root.addView(actions, actionParams)
        root.addView(TextView(this).apply {
            text = "تنظیم‌کننده: محمد اختری"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(2))
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun render() {
        if (!::results.isInitialized) return
        results.removeAllViews()
        val q = lastSearchQuery
        countLabel.text = "تعداد رکوردها: ${rows.size}   |   کدهای یکتا: ${index.size}"
        if (q == null || q.isEmpty()) {
            results.addView(infoCard("کد کالا را وارد کنید و دکمه «جستجوی کد» را بزنید."))
            return
        }
        val found = index[q].orEmpty()
        results.addView(infoCard("نتیجه جستجوی ${query.text}  —  ${found.size} محل ثبت‌شده"))
        if (found.isEmpty()) {
            results.addView(infoCard("این کد در اطلاعات انبار پیدا نشد."))
            return
        }
        found.forEachIndexed { i, p ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(Color.WHITE, 14, Color.rgb(225, 233, 241))
            }
            val title = TextView(this).apply {
                text = "محل ${i + 1}"
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(blue)
            }
            card.addView(title)
            card.addView(TextView(this).apply {
                text = "سمت: ${p.side}     طبقه: ${p.level}     پالت: ${p.pallet}"
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(ink)
                setPadding(0, dp(9), 0, dp(5))
            })
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(9)
            results.addView(card, lp)
        }
    }

    private fun infoCard(message: String): View = TextView(this).apply {
        text = message
        textSize = 15f
        setTextColor(ink)
        setPadding(dp(14), dp(15), dp(14), dp(15))
        background = rounded(Color.WHITE, 12, Color.rgb(225, 233, 241))
    }

    private fun editPlace(old: Place?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(4))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val code = EditText(this).apply { hint = "کد کالا"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(old?.code ?: "") }
        val side = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("چپ", "راست"))
            setSelection(if (old?.side == "راست") 1 else 0)
        }
        val levelOptions = listOf("اول", "دوم", "سوم")
        val level = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, levelOptions)
            setSelection(levelOptions.indexOf(old?.level).coerceAtLeast(0))
        }
        val pallet = EditText(this).apply { hint = "شماره پالت"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(old?.pallet ?: "") }
        box.addView(code); box.addView(side); box.addView(level); box.addView(pallet)
        AlertDialog.Builder(this).setTitle(if (old == null) "ثبت کد جدید" else "ویرایش محل")
            .setView(box).setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val c = code.text.toString().trim()
                val p = pallet.text.toString().trim()
                if (c.isNotEmpty() && p.isNotEmpty()) {
                    if (old != null) rows.remove(old)
                    rows.add(Place(c, side.selectedItem.toString(), level.selectedItem.toString(), p))
                    saveAndRefresh()
                } else Toast.makeText(this, "کد و شماره پالت را وارد کنید", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun chooseImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, importCode)
    }

    private fun chooseExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_کدهای_انبار.xlsx")
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, exportCode)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (requestCode == importCode) confirmImport(uri)
            if (requestCode == exportCode) exportExcel(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در فایل: ${e.message ?: "نامشخص"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmImport(uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle("جایگزینی اطلاعات انبار")
            .setMessage("با ورود فایل جدید، اطلاعات فعلی برنامه با ردیف‌های معتبر فایل جایگزین می‌شود. قبل از ادامه، از اطلاعات فعلی خروجی پشتیبان بگیرید. کدهای تکراری حذف نمی‌شوند و همه محل‌ها باقی می‌مانند.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه و ورود فایل") { _, _ -> importExcel(uri) }
            .show()
    }

    private fun importExcel(uri: Uri) {
        val imported = mutableListOf<Place>()
        var skipped = 0
        val input = contentResolver.openInputStream(uri) ?: error("فایل قابل خواندن نیست")
        input.use { stream ->
            XSSFWorkbook(stream).use { book ->
                val sheet = book.getSheet("ثبت کدها") ?: book.getSheetAt(0)
                val fmt = DataFormatter()
                for (r in 1..sheet.lastRowNum) {
                    val row = sheet.getRow(r) ?: continue
                    val c = fmt.formatCellValue(row.getCell(0)).trim()
                    val s = fmt.formatCellValue(row.getCell(1)).trim()
                    val l = fmt.formatCellValue(row.getCell(2)).trim()
                    val p = fmt.formatCellValue(row.getCell(3)).trim()
                    if (c.isEmpty() && s.isEmpty() && l.isEmpty() && p.isEmpty()) continue
                    if (c.isNotEmpty() && s.isNotEmpty() && l.isNotEmpty() && p.isNotEmpty()) {
                        imported.add(Place(c, s, l, p))
                    } else skipped++
                }
            }
        }
        if (imported.isEmpty()) {
            Toast.makeText(this, "ردیف معتبر پیدا نشد؛ اطلاعات قبلی حفظ شد.", Toast.LENGTH_LONG).show()
            return
        }
        rows.clear()
        rows.addAll(imported)
        saveAndRefresh()
        Toast.makeText(this, "${imported.size} ردیف وارد شد؛ ${skipped} ردیف ناقص نادیده گرفته شد. تکراری‌ها حفظ شدند.", Toast.LENGTH_LONG).show()
    }

    private fun exportExcel(uri: Uri) {
        XSSFWorkbook().use { book ->
            val sheet = book.createSheet("ثبت کدها")
            val header = sheet.createRow(0)
            listOf("کد کالا", "سمت", "طبقه", "شماره پالت").forEachIndexed { i, v -> header.createCell(i).setCellValue(v) }
            rows.forEachIndexed { i, p ->
                val r = sheet.createRow(i + 1)
                r.createCell(0).setCellValue(p.code); r.createCell(1).setCellValue(p.side)
                r.createCell(2).setCellValue(p.level); r.createCell(3).setCellValue(p.pallet)
            }
            for (i in 0..3) sheet.setColumnWidth(i, 5000)
            val output = contentResolver.openOutputStream(uri) ?: error("فایل خروجی ساخته نشد")
            output.use { book.write(it) }
        }
        Toast.makeText(this, "فایل پشتیبان ساخته شد", Toast.LENGTH_LONG).show()
    }

    private fun saveAndRefresh() {
        save()
        rebuildIndex()
        render()
    }

    private fun rebuildIndex() {
        index.clear()
        rows.forEach { place -> index.getOrPut(normalize(place.code)) { mutableListOf() }.add(place) }
    }

    private fun normalize(value: String): String {
        val ascii = value.trim().map { ch ->
            when (ch) {
                in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                else -> ch
            }
        }.joinToString("")
        return ascii.trimStart('0').ifEmpty { if (ascii.isNotEmpty()) "0" else "" }
    }

    private fun save() {
        val a = JSONArray()
        rows.forEach { p -> a.put(JSONObject().put("code", p.code).put("side", p.side).put("level", p.level).put("pallet", p.pallet)) }
        storage.edit().putString("rows", a.toString()).apply()
    }

    private fun loadSaved() {
        val a = JSONArray(storage.getString("rows", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            rows.add(Place(o.optString("code"), o.optString("side"), o.optString("level"), o.optString("pallet")))
        }
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 10)
        setPadding(dp(4), dp(5), dp(4), dp(5))
        setOnClickListener { action() }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(46), 1f).apply {
        marginStart = dp(3); marginEnd = dp(3)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
