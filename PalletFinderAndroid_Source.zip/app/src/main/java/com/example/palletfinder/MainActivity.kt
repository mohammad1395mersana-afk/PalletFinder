package com.example.palletfinder

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.ss.usermodel.DataFormatter
import org.json.JSONArray
import org.json.JSONObject

data class Place(val code:String, val side:String, val level:String, val pallet:String)

class MainActivity : Activity() {
    private val rows = mutableListOf<Place>()
    private lateinit var storage: android.content.SharedPreferences
    private lateinit var query: EditText
    private lateinit var results: LinearLayout
    private val importCode = 10
    private val exportCode = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = getSharedPreferences("pallet_data", MODE_PRIVATE)
        loadSaved()
        buildUi()
        render()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 20)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "جستجوی کد انبار"; textSize = 24f; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        query = EditText(this).apply {
            hint = "کد کالا را وارد کنید"; textSize = 20f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            addTextChangedListener(object: android.text.TextWatcher {
                override fun beforeTextChanged(s:CharSequence?, start:Int,count:Int,after:Int) {}
                override fun onTextChanged(s:CharSequence?, start:Int,before:Int,count:Int) { render() }
                override fun afterTextChanged(s:android.text.Editable?) {}
            })
        }
        root.addView(query)
        val search = Button(this).apply { text = "جستجو"; setOnClickListener { render() } }
        root.addView(search)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "ورود اکسل"; setOnClickListener { chooseImport() } }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(Button(this).apply { text = "خروجی اکسل"; setOnClickListener { chooseExport() } }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(Button(this).apply { text = "ثبت کد"; setOnClickListener { editPlace(null) } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(actions)
        setContentView(root)
    }

    private fun render() {
        if (!::results.isInitialized) return
        results.removeAllViews()
        val q = query.text.toString().trim()
        if (q.isEmpty()) {
            results.addView(label("برای جستجو، کد کالا را وارد کنید."))
            results.addView(label("تعداد رکوردهای ذخیره‌شده: ${rows.size}"))
            return
        }
        val found = rows.filter { it.code.trim().trimStart('0') == q.trimStart('0') || it.code.trim() == q }
        results.addView(label("نتیجه جستجوی $q — ${found.size} محل"))
        if (found.isEmpty()) results.addView(label("کدی با این مشخصات پیدا نشد."))
        found.forEachIndexed { index, p ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16,12,16,12)
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            }
            card.addView(label("محل ${index+1}"))
            card.addView(label("سمت: ${p.side}   |   طبقه: ${p.level}   |   پالت: ${p.pallet}"))
            val edit = Button(this).apply { text = "ویرایش"; setOnClickListener { editPlace(p) } }
            val del = Button(this).apply { text = "حذف"; setOnClickListener {
                rows.remove(p); save(); render()
            } }
            val line = LinearLayout(this)
            line.addView(edit, LinearLayout.LayoutParams(0,-2,1f))
            line.addView(del, LinearLayout.LayoutParams(0,-2,1f))
            card.addView(line)
            results.addView(card)
        }
    }

    private fun label(s:String) = TextView(this).apply {
        text=s; textSize=17f; setPadding(8,10,8,10)
    }

    private fun editPlace(old:Place?) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,8) }
        val code = EditText(this).apply { hint="کد کالا"; inputType=android.text.InputType.TYPE_CLASS_NUMBER; setText(old?.code ?: "") }
        val side = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("چپ","راست")); setSelection(if(old?.side=="راست") 1 else 0) }
        val level = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("اول","دوم","سوم")); setSelection(listOf("اول","دوم","سوم").indexOf(old?.level).coerceAtLeast(0)) }
        val pallet = EditText(this).apply { hint="شماره پالت"; inputType=android.text.InputType.TYPE_CLASS_NUMBER; setText(old?.pallet ?: "") }
        box.addView(code); box.addView(side); box.addView(level); box.addView(pallet)
        android.app.AlertDialog.Builder(this).setTitle(if(old==null) "ثبت کد جدید" else "ویرایش محل")
            .setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره") { _,_ ->
                val c=code.text.toString().trim(); val p=pallet.text.toString().trim()
                if(c.isNotEmpty() && p.isNotEmpty()) {
                    if(old!=null) rows.remove(old)
                    rows.add(Place(c,side.selectedItem.toString(),level.selectedItem.toString(),p))
                    save(); render()
                } else Toast.makeText(this,"کد و شماره پالت را وارد کنید",Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun chooseImport() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(i,importCode)
    }
    private fun chooseExport() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; putExtra(Intent.EXTRA_TITLE,"پشتیبان_کدهای_انبار.xlsx") }
        startActivityForResult(i,exportCode)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK) return
        val uri=data?.data ?: return
        try {
            if(requestCode==importCode) importExcel(uri)
            if(requestCode==exportCode) exportExcel(uri)
        } catch(e:Exception) {
            Toast.makeText(this,"خطا در فایل: ${e.message}",Toast.LENGTH_LONG).show()
        }
    }

    private fun importExcel(uri:Uri) {
        contentResolver.openInputStream(uri).use { input ->
            val book=XSSFWorkbook(input)
            val sheet=book.getSheet("ثبت کدها") ?: book.getSheetAt(0)
            val fmt=DataFormatter()
            val imported= mutableListOf<Place>()
            for(r in 1..sheet.lastRowNum) {
                val row=sheet.getRow(r) ?: continue
                val c=fmt.formatCellValue(row.getCell(0)).trim()
                val s=fmt.formatCellValue(row.getCell(1)).trim()
                val l=fmt.formatCellValue(row.getCell(2)).trim()
                val p=fmt.formatCellValue(row.getCell(3)).trim()
                if(c.isNotEmpty() && p.isNotEmpty()) imported.add(Place(c,s,l,p))
            }
            rows.clear(); rows.addAll(imported); book.close(); save(); render()
            Toast.makeText(this,"${rows.size} ردیف وارد شد",Toast.LENGTH_LONG).show()
        }
    }

    private fun exportExcel(uri:Uri) {
        val book=XSSFWorkbook()
        val sheet=book.createSheet("ثبت کدها")
        val headers=listOf("کد کالا","سمت","طبقه","شماره پالت")
        val h=sheet.createRow(0); headers.forEachIndexed { i,v -> h.createCell(i).setCellValue(v) }
        rows.forEachIndexed { i,p ->
            val r=sheet.createRow(i+1)
            r.createCell(0).setCellValue(p.code); r.createCell(1).setCellValue(p.side)
            r.createCell(2).setCellValue(p.level); r.createCell(3).setCellValue(p.pallet)
        }
        for(i in 0..3) sheet.setColumnWidth(i,5000)
        contentResolver.openOutputStream(uri).use { book.write(it) }
        book.close()
        Toast.makeText(this,"فایل پشتیبان ساخته شد",Toast.LENGTH_LONG).show()
    }

    private fun save() {
        val a=JSONArray()
        rows.forEach { p -> a.put(JSONObject().put("code",p.code).put("side",p.side).put("level",p.level).put("pallet",p.pallet)) }
        storage.edit().putString("rows",a.toString()).apply()
    }
    private fun loadSaved() {
        val a=JSONArray(storage.getString("rows","[]"))
        for(i in 0 until a.length()) {
            val o=a.getJSONObject(i)
            rows.add(Place(o.optString("code"),o.optString("side"),o.optString("level"),o.optString("pallet")))
        }
    }
}
